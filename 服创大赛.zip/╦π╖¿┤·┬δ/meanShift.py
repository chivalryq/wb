import sys
import pandas as pd
import numpy as np
import sklearn.datasets as sld 
import sklearn.cluster as slc
from sklearn.metrics import silhouette_score as skl_silScore
from sklearn.metrics import calinski_harabasz_score as skl_calScore
import matplotlib.pyplot as plt
import mpl_toolkits.mplot3d
from sklearn.preprocessing import StandardScaler
# 对类别进行统计,输出一个包含类别和数目信息的字典
def tallyClusters(Clist):
	# 将narray数据转化为list
	S = Clist.tolist()
	# 统计每一类的数量
	classN=dict()
	for i in range(len(S)):
		classN[S[i]] = classN.get(S[i], 0) + 1
	return classN

# 对分类的统计结果进行图像化显示
def paintResult(resultDict):
	# 数值列表
	num_list = []
	# 名字列表
	name_list = []
	# 填充两个列表
	for k,v in resultDict.items():
		name_list.append(k)
		num_list.append(v)
	
	plt.figure()
	# 画出直方图
	rects = plt.bar(name_list,num_list)
	plt.xticks(name_list)
	# 标注数据
	
	for rect in rects:
		x = rect.get_x()
		width = rect.get_width()
		height = rect.get_height()
		plt.text(x+width/2,height,height,ha='center', va='bottom',fontsize=10)
	
	# 设置打开交互模式而不阻塞
	plt.ion()
	# show出来
	plt.show()
	
	


# mean-shift聚类
def Mean_Shift(data,qtl=0.2,nPoint=50):
	bandwidth = slc.estimate_bandwidth(data, quantile=qtl, n_samples=nPoint)
	ms = slc.MeanShift(bandwidth=bandwidth, bin_seeding=True)
	result = ms.fit_predict(data)
	# 返回得到的结果和分类器
	return result,ms



## 对于mean-shift算法的前验分析
def meanShiftCMP(data,qtlMin,qtlMax,nPointMin,nPointMax,qtlStep=0.1,nPointStep=10):
	print("分位数\t每类样本数\t轮廓系数\tCalinski-Harabasz指数\t分类结果")
	bestqtl_sil=qtlMin
	bestnPoint_sil=nPointMin
	bestqtl_cal=qtlMin
	bestnPoint_cal=nPointMin
	
	qtl = []
	nPoint = []
	sil = []
	cal = []
	
	bestSilScore=0
	bestCalScore=0
	
	fig = plt.figure()
	tDsil = fig.add_subplot(121,projection='3d')
	tDcal = fig.add_subplot(122,projection='3d')
	tDsil.set_title("silhouette Score")
	tDcal.set_title("Calinski-Harabasz Score")
	i = qtlMin
	while i < qtlMax :
		print("in")
		for j in range(nPointMin,nPointMax+1,nPointStep):
			bandwidth = slc.estimate_bandwidth(data, quantile=i, n_samples=j)
			ms = slc.MeanShift(bandwidth=bandwidth, bin_seeding=True)
			result = ms.fit_predict(data)
			finalResult = tallyClusters(result)
			silScore = skl_silScore(data,result)
			calScore = skl_calScore(data,result)
			qtl.append(i)
			nPoint.append(j)
			sil.append(silScore)
			cal.append(calScore)
			print(i,"\t",j,"\t",silScore,"\t",calScore,"\t", finalResult)
			if silScore > bestSilScore:
				bestSilScore = silScore
				bestqtl_sil = i
				bestnPoint_sil =j
			if calScore > bestCalScore:
				bestCalScore = calScore
				bestqtl_cal = i
				bestnPoint_cal =j
		i = i + qtlStep
	
	tDsil.bar3d([x-0.2*qtlStep for x in qtl], [x-0.2*nPointStep for x in nPoint] ,np.zeros_like(qtl),dx=0.4*qtlStep,dy=0.4*nPointStep,dz=sil)
	tDsil.set_xlabel("quantile")
	tDsil.set_ylabel("n_samples")
	tDsil.set_zlabel("silhouette_score")
	
	tDcal.bar3d([x-0.2*qtlStep for x in qtl], [x-0.2*nPointStep for x in nPoint] ,np.zeros_like(qtl),dx=0.4*qtlStep,dy=0.4*nPointStep,dz=cal,color="yellow")
	tDcal.set_xlabel("quantile")
	tDcal.set_ylabel("n_samples")
	tDcal.set_zlabel("Calinski-Harabasz_Score")
	
	print("当分位数为",bestqtl_sil,"每类样本数为",bestnPoint_sil,"时,轮廓系数最佳")
	print("当分位数为",bestqtl_cal,"每类样本数为", bestnPoint_cal ,"时,Calinski-Harabasz指数最佳")
	plt.ion()
	plt.show()
	


# Main function
def main():
	# 数据导入
	if len(sys.argv) == 1 :
		print("Need a file at least")
	else:
		# 存储属性数据
		data = []
		# 存储公司名称，即键值数据
		names = []
		# 导入数据
		pos = 2 if sys.argv[1]=='-c' else 1
		try:	
			with open(sys.argv[pos],'r')as f:
				lines = f.readlines()
				propertyName = lines.pop(0)
				for line in lines:
					cells = line.strip().split(',')
					names.append(cells[0])
					data.append([float(cells[i]) for i in range(1,len(cells))])
			scaler = StandardScaler()
			data = scaler.fit_transform(data)
			print(data)
			if pos == 1 :
				if len(sys.argv)==4 and type(eval(sys.argv[2]))==float and type(eval(sys.argv[3]))==int:
					result,sorter = Mean_Shift(data,float(sys.argv[2]),int(sys.argv[3]))
				else:
					result,sorter = Mean_Shift(data)
				finalResult = tallyClusters(result)
				print("[分类及数量]:",finalResult)
				paintResult(finalResult)
				print("[轮廓系数]:",skl_silScore(data,result))
				print('[Calinski-Harabasz指数]:',skl_calScore(data,result))
				plt.show()
			else:
				if type(eval(sys.argv[3]))==float and type(eval(sys.argv[4]))==float and float(sys.argv[3])<float(sys.argv[4]) and\
				type(eval(sys.argv[5]))==int and type(eval(sys.argv[6]))==int and int(sys.argv[5])<int(sys.argv[6]) :
					# 打印类比结果	
					if len(sys.argv)==9 and type(eval(sys.argv[7]))==float and type(eval(sys.argv[8]))==int:
						meanShiftCMP(data,float(sys.argv[3]), float(sys.argv[4]), int(sys.argv[5]), int(sys.argv[6]), float(sys.argv[7]), int(sys.argv[8]))
					else:
						meanShiftCMP(data,float(sys.argv[3]), float(sys.argv[4]), int(sys.argv[5]), int(sys.argv[6]))
			input("[Pressed any key to quit...]")
		except FileNotFoundError:
			print('["'+sys.argv[pos]+'" is not a file!]')
		except IndexError :
			print("[Arguments wrong!]")
# Entrance
main()